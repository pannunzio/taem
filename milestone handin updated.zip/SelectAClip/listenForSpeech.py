import argparse
import math
import pythonosc
import speech_recognition as speechRec
import pyttsx3
import urllib.request
from pythonosc import dispatcher as dispatch
from pythonosc import osc_server
from pythonosc import osc_message_builder
from pythonosc import udp_client

#client info
parser2 = argparse.ArgumentParser()
parser2.add_argument("--ip",
    default="127.0.0.1", help="The ip to talk on")
parser2.add_argument("--port",
    type=int, default=11999, help="The port to talk on")
args2 = parser2.parse_args()

client = udp_client.UDPClient(args2.ip, args2.port)

def pry():
    print("prying")
    recognizer = speechRec.Recognizer()
    mic = speechRec.Microphone()
    value = None
    try:
        with mic as source:
            recognizer.adjust_for_ambient_noise(source)
        recognizer.dynamic_energy_threshold = True
    #    print("Set minimum energy threshold to {}".format(recognizer.energy_threshold))
     #   print("Detecting audio...")
        with mic as source:
            audio = recognizer.listen(source, 10.0, 5.0, None)
        try:
            value = recognizer.recognize_google(audio)
            print("value: {}".format(value))
        except speechRec.UnknownValueError:
            return None
        except speechRec.RequestError as e:
    #        print("Uh oh! Couldn't request results from Google Speech Recognition service; {0}".format(e))
            return None
    except KeyboardInterrupt:
        return "error"
    return value

def print_volume_handler(unused_addr, args, volume):
  print("[{0}] ~ {1}".format(args[0], volume))

def print_compute_handler(unused_addr, args, volume):
  try:
    print("[{0}] ~ {1}".format(args[0], args[1](volume)))
  except ValueError: pass

def send_msg(info):
    msg = osc_message_builder.OscMessageBuilder(address = "/mouth")
    sentence = pry()
    while 1:
        sentence = pry()
        print("the sentence: " + sentence)
        msg.add_arg(sentence)
        msg = msg.build()
        print("msg: " + str(msg))
        client.send(msg)

def main():
  #server info
  parser = argparse.ArgumentParser()
  parser.add_argument("--ip",
      default="127.0.0.1", help="The ip to listen on")
  parser.add_argument("--port",
      type=int, default=12000, help="The port to listen on")
  args = parser.parse_args()

  dispatcher = dispatch.Dispatcher()
  dispatcher.map("/trigger", send_msg)
  dispatcher.map("/volume", print_volume_handler, "Volume")
  dispatcher.map("/logvolume", print_compute_handler, "Log volume", math.log)

  server = osc_server.ThreadingOSCUDPServer(
      (args.ip, args.port), dispatcher)
  print("Serving on {}".format(server.server_address))
  server.serve_forever()

main()
